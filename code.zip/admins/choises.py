CHOICES = (
    ('mobile','mobile'),
    ('laptop','laptop'),
    ('mobile accessories','mobile accessories'),
    ('watches','watches'),
    ('TV','TV'),
    ('shoes','shoes'),
    ('mens dress','mens dress'),
    ('womens dresss','womens dress'),
)